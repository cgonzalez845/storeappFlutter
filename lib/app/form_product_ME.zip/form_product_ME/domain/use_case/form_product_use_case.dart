import 'package:storeapp/app/form_product/data/repository/form_product_repository_impl.dart';
import 'package:storeapp/app/form_product/domain/repository/form_product_repository.dart';
import 'package:storeapp/app/form_product/presentation/model/form_product_model.dart';

class FormProductUseCase {
  late final FormProductRepository _formProductRepository;

  FormProductUseCase() {
    _formProductRepository = FormProductRepositoryImpl();
  }

  bool invoke(FormProductModel formProductModel) {
    final data = formProductModel.toEntity();
    return _formProductRepository.addProduct(data);
  }
}

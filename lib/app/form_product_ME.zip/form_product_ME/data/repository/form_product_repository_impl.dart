import 'dart:math';

import 'package:storeapp/app/core/domain/entity/product_entity.dart';
import 'package:storeapp/app/form_product/domain/repository/form_product_repository.dart';
import 'package:storeapp/app/login/domain/entity/login_entity.dart';
import 'package:storeapp/app/login/domain/repository/login_repository.dart';

class FormProductRepositoryImpl implements FormProductRepository {
  @override
  bool addProduct(ProductEntity productEntity) {
    // TODO: implement addProduct
    throw UnimplementedError();
  }
  
}
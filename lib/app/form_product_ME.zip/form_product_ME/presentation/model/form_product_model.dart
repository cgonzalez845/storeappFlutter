import 'dart:ffi';

import 'package:storeapp/app/core/domain/entity/product_entity.dart';
import 'package:storeapp/app/login/domain/entity/login_entity.dart';

final class FormProductModel {
  final String id;
  final String name;
  final String price;
  final String image;

  FormProductModel({
    required this.id,
    required this.name,
    required this.price,
    required this.image,
  });

  FormProductModel copyWith({
    String? id,
    String? name,
    String? price,
    String? image,
  }) {
    return FormProductModel(
      id: id ?? this.id,
      name: name ?? this.id,
      price: price ?? this.price,
      image: image ?? this.image,
    );
  }

  ProductEntity toEntity() => ProductEntity(
    id: id,
    name: name,
    image: image,
    price: double.parse(price),
  );
}

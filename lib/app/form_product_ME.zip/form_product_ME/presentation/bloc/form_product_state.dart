import 'package:storeapp/app/form_product/presentation/model/form_product_model.dart';
import 'package:storeapp/app/login/presentation/model/login_form_model.dart';

sealed class FormProductState {
  FormProductState({required this.model});

  final FormProductModel model;
}

final class InitialState extends FormProductState {
  InitialState() : super(model: FormProductModel(id: "", name: "", price: "", image: ""));
  //InitialState({required super.model});
}

final class DataUpdateState extends FormProductState {
  DataUpdateState({required super.model});
}

final class DataUpdateSuccessState extends FormProductState {
  DataUpdateSuccessState({required super.model});
}

final class DataUpdateErrorState extends FormProductState {
  DataUpdateErrorState({required super.model, String? message});
}

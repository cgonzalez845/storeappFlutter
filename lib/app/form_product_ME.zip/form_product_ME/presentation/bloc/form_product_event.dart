import 'dart:ffi';

sealed class FormProductEvent {}

final class NameChangedEvent extends FormProductEvent {
  final String name;
  NameChangedEvent({required this.name});
}

final class PriceChangedEvent extends FormProductEvent {
  final String price;
  PriceChangedEvent({required this.price});
}

final class ImageChangedEvent extends FormProductEvent {
  final String image;
  ImageChangedEvent({required this.image});
}

final class SubmitEvent extends FormProductEvent {
  SubmitEvent();
}
